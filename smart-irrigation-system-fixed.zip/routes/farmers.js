const express = require('express');
const router = express.Router();
const db = require('../db/config');

// GET all farmers
router.get('/', (req, res) => {
  db.query('SELECT * FROM tbl_farmers', (err, results) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json(results);
  });
});

// POST new farmer
router.post('/', (req, res) => {
  const { name, location, crop } = req.body;
  db.query('INSERT INTO tbl_farmers (name, location, crop) VALUES (?, ?, ?)', 
    [name, location, crop],
    (err, result) => {
      if (err) return res.status(500).json({ error: err.message });
      res.status(201).json({ message: 'Farmer added', id: result.insertId });
    }
  );
});

module.exports = router;
